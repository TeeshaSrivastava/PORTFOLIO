<footer>
  <p>© <?php echo date("Y"); ?> Teesha. All rights reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
